<?php
	
	class Reviewer{
		var $conferenceId;
		var $reviewerId;
		var $name;
		var $phoneNo;
		var $address;
		var $email;

		function getData(){
			$this->conferenceId=$_GET['conferenceid'];
			$this->reviewerId=$_GET['reviewerid'];
			$this->name=$_GET['name'];
			$this->phoneNo=$_GET['phoneNo'];
			$this->address=$_GET['address'];
			$this->email=$_GET['email'];
		}

	}

	$obj = new Reviewer();
	$obj->getData();

	include("connection.php");
	$co=  new Connection1();


	//Connection1::$conn = new mysqli("localhost", "ikram", "1126","conference");

	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}

	$q= "update Reviewer set name=\"".$obj->name."\", phoneNo=\"".$obj->phoneNo."\",  address=\"".$obj->address."\", email=\"".$obj->email."\" where reviewerid=".$obj->reviewerId.";";
	if(mysqli_query(Connection1::$conn,$q)==true){
		echo "user added<br>  ";
	}
	else {
		echo mysqli_error(Connection1::$conn);
	}
	echo '<script type="text/javascript">
           window.location = "http://localhost/cms/adminpanelreviewer.php";
      	</script>';

?>