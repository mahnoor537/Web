<?php

	class FinalPaper{
		var $paperId;
		var $file;

		function getData(){
			session_start();
			$this->paperId= $_SESSION['paperid'];

		}
	}


	$obj = new FinalPaper();
	$obj->getData();	
	
    include("connection.php");
    $co=  new Connection1();

    //Connection1::$conn = new mysqli("localhost", "ikram", "1126","conference");

	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}
	$obj->file = $_FILES["file"]["name"];


	$q= "insert into finalpaper (paperid,path)
		values(".$obj->paperId.",\"".$obj->file."\");";

	echo $q;
	$targetDir = "finalpapers/";
$fileName = $_FILES["file"]["name"];

$targetFilePath = $targetDir . $fileName;

$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
//$id = $_REQUEST['search1'];
//echo $id;
//global $db;
//$email = $_REQUEST['email1'];
//echo $email;
//echo $fileName;
if(!empty($_FILES["file"]["name"])){
    // Allow certain file formats
    $allowTypes = array('jpg','png','jpeg','gif','pdf','docx');
    if(in_array($fileType, $allowTypes))
    {
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath))
        {
            // Insert image file name into database
            //var_dump('NOW()');
        		$insert=mysqli_query(Connection1::$conn,$q);
	
        		
            //	var_dump($insert);
            if($insert)
            {	
            	$qr="update submittedpaper set status=1 where paperid=".$obj->paperId.";";
            	if(mysqli_query(Connection1::$conn,$qr)){
            		echo "done";
            	}
            	else{
            		echo "not done";
            	}
                header('Location: http://localhost/cms/userHome.php');

            }
            else
            {
                $statusMsg = "File upload failed, please try again.";
            } 
        }
        else
        {
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }
    else
    {
        $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
    }
}
else
{
    $statusMsg = 'Please select a file to upload.';
}

// Display status message
echo $statusMsg;

?>