-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2019 at 07:17 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `conference`
--

-- --------------------------------------------------------

--
-- Table structure for table `conference`
--

CREATE TABLE `conference` (
  `conferenceid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `hdate` date DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conference`
--

INSERT INTO `conference` (`conferenceid`, `name`, `hdate`, `description`, `address`, `email`) VALUES
(13, 'ikram', '2019-04-27', 'zxfgasgfgdsfg', 'guyugftrd', 'gfuhgkjh');

-- --------------------------------------------------------

--
-- Table structure for table `conferenceuser`
--

CREATE TABLE `conferenceuser` (
  `userid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) DEFAULT NULL,
  `phoneNo` varchar(20) DEFAULT NULL,
  `psw` varchar(20) DEFAULT NULL,
  `institutionName` varchar(50) DEFAULT NULL,
  `role` char(1) DEFAULT NULL,
  `conferenceid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conferenceuser`
--

INSERT INTO `conferenceuser` (`userid`, `name`, `email`, `phoneNo`, `psw`, `institutionName`, `role`, `conferenceid`) VALUES
(27, 'ikram ul haq', 'ulhaqi12@gmail.com', '03032119999', 'ikram', 'pucit', 'A', NULL),
(49, 'user', 'u@gmail.com', '124135', '123', '4635', 'U', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `finalpaper`
--

CREATE TABLE `finalpaper` (
  `finalid` int(11) NOT NULL,
  `paperid` int(11) DEFAULT NULL,
  `path` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `finalpaper`
--

INSERT INTO `finalpaper` (`finalid`, `paperid`, `path`) VALUES
(13, 29, 'inhertitance.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `reviewer`
--

CREATE TABLE `reviewer` (
  `reviewerid` int(11) NOT NULL,
  `conferenceid` int(11) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `phoneNo` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `psw` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviewer`
--

INSERT INTO `reviewer` (`reviewerid`, `conferenceid`, `name`, `phoneNo`, `address`, `email`, `psw`) VALUES
(15, 13, 'ali', '4646', 'islamabad', 'r@gmail.com', 123);

-- --------------------------------------------------------

--
-- Table structure for table `submittedpaper`
--

CREATE TABLE `submittedpaper` (
  `paperId` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `path` varchar(100) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `conferenceid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submittedpaper`
--

INSERT INTO `submittedpaper` (`paperId`, `title`, `path`, `userId`, `conferenceid`, `status`) VALUES
(29, 'a', 'inhertitance.pdf', 49, 13, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `conference`
--
ALTER TABLE `conference`
  ADD PRIMARY KEY (`conferenceid`,`name`);

--
-- Indexes for table `conferenceuser`
--
ALTER TABLE `conferenceuser`
  ADD PRIMARY KEY (`userid`,`name`),
  ADD KEY `conferenceid` (`conferenceid`);

--
-- Indexes for table `finalpaper`
--
ALTER TABLE `finalpaper`
  ADD PRIMARY KEY (`finalid`),
  ADD KEY `paperid` (`paperid`);

--
-- Indexes for table `reviewer`
--
ALTER TABLE `reviewer`
  ADD PRIMARY KEY (`reviewerid`,`name`),
  ADD KEY `conferenceid` (`conferenceid`);

--
-- Indexes for table `submittedpaper`
--
ALTER TABLE `submittedpaper`
  ADD PRIMARY KEY (`paperId`,`title`),
  ADD KEY `userId` (`userId`),
  ADD KEY `conferenceid` (`conferenceid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `conference`
--
ALTER TABLE `conference`
  MODIFY `conferenceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `conferenceuser`
--
ALTER TABLE `conferenceuser`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `finalpaper`
--
ALTER TABLE `finalpaper`
  MODIFY `finalid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `reviewer`
--
ALTER TABLE `reviewer`
  MODIFY `reviewerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `submittedpaper`
--
ALTER TABLE `submittedpaper`
  MODIFY `paperId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `conferenceuser`
--
ALTER TABLE `conferenceuser`
  ADD CONSTRAINT `conferenceuser_ibfk_1` FOREIGN KEY (`conferenceid`) REFERENCES `conference` (`conferenceid`);

--
-- Constraints for table `finalpaper`
--
ALTER TABLE `finalpaper`
  ADD CONSTRAINT `finalpaper_ibfk_1` FOREIGN KEY (`paperid`) REFERENCES `submittedpaper` (`paperId`);

--
-- Constraints for table `reviewer`
--
ALTER TABLE `reviewer`
  ADD CONSTRAINT `reviewer_ibfk_1` FOREIGN KEY (`conferenceid`) REFERENCES `conference` (`conferenceid`);

--
-- Constraints for table `submittedpaper`
--
ALTER TABLE `submittedpaper`
  ADD CONSTRAINT `submittedpaper_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `conferenceuser` (`userid`),
  ADD CONSTRAINT `submittedpaper_ibfk_2` FOREIGN KEY (`conferenceid`) REFERENCES `conference` (`conferenceid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
