<?php

	class Connection1 
	{
		public  static $count=0;	
		public  static $conn;
		function Connection1(){
			if(static::$count==0)
				static::$conn = new mysqli("localhost:3308", "root", "","conference1");
			else return static::$conn;
			static::$count++;
		}
	}
?>