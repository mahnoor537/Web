<?php
	include("connection.php");
	$co=  new Connection1();

	//Connection1::$conn = new mysqli("localhost", "ikram", "1126","conference");

    // Check connection
    if (Connection1::$conn->connect_error) {
        die("Connection failed: " . Connection1::$conn->connect_error);
    }
	session_start();
      
	$q= "update submittedpaper set status=-2 where paperid=".$_GET['paperid'].";";
      
    if (mysqli_query(Connection1::$conn,$q)==true) {
		//echo "updated";
	}    
	else{
		//echo "not updated";
	}
	echo '<script type="text/javascript">
           window.location = "http://localhost/cms/reviewerPanel.php";
      	</script>';

?>