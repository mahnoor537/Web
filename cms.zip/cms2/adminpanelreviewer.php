<!DOCTYPE html>
<html lang="en">
<title>home- CMS</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="cssfile1.css">
<link rel="stylesheet" href="cssfile2.css">
<link rel="stylesheet" href="cssfile3.css">
<link rel="stylesheet" href="cssfile4.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
}

/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}
/* The sidebar menu */
.sidenav {

  margin-top: 50px;
  height: 100%; /* Full-height: remove this if you want "auto" height */
  width: 200px; /* Set the width of the sidebar */
  position: fixed; /* Fixed Sidebar (stay in place on scroll) */
  z-index: 1; /* Stay on top */
  top: 0; /* Stay at the top */
  left: 0;
  background-color: #111; /* Black */
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 20px;
}

/* The navigation menu links */
.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
}

/* When you mouse over the navigation links, change their color */
.sidenav a:hover {
  color: #f1f1f1;
}

/* Style page content */
.main {
    margin-top: 50px;
  margin-left: 200px; /* Same as the width of the sidebar */
  padding: 0px 10px;
}

/* On smaller screens, where height is less than 450px, change the style of the sidebar (less padding and a smaller font size) */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


table{
    text-align: center;
  }
  table {
    float: left;
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 90%;
  margin: 5%;
}

table td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4c73af;
  color: white;
}

  th{
    color :white;
    background-color: #4c73af;
  }
</style>
<body>

<div class="w3-top">
  <div class="w3-bar w3-red w3-card w3-left-align w3-medium">
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-red" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <font style="float:left; font-size: 25px;">Conference Management System</font>
    <a href="logout.php"><button style=" width:8%;float: right; ">log out</button></a>
  </div>
</div>

<!-- Side navigation -->
<div class="sidenav">
  <a href="adminpanel.php">Conferences</a>
  <a style="color: #f1f1f1;" href="adminpanelreviewer.php">Reviewers</a>
  <a href="addConference.php">Add Conference</a>
  <a href="addReviewer.php">Add Reviewer</a>
</div>

<!-- Page content -->
<div class="main">
  <?php
    $conn = new mysqli("localhost:3308", "root", "","conference1");

      // Check connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      $q= "select * from reviewer;";

      $result = mysqli_query($conn,$q);
      echo "<table><th>R No.</th><th>C No.</th><th>Name</th><th>Phone No</th><th>Address</th><th>Email</th><th></th><th></th>";
      if ($result->num_rows > 0) {
           //output data of each row
          while($row = $result->fetch_assoc()) {
          echo "<tr><td>".$row['reviewerid']."</td><td>".$row['conferenceid']."</td><td>".$row['name']."</td><td>".$row['phoneNo']."</td><td>".$row['address']."</td><td>".$row['email']."</td><td><form action=\"updatereviewer.php\"><input type=\"hidden\" value=\"".$row['conferenceid']."\" name=\"conferenceid\"><input type=\"hidden\" value=\"".$row['reviewerid']."\" name=\"reviewerid\"><button>Update</button></td></form><td><form action=\"deletereviewer.php\"><input type=\"hidden\" value=\"".$row['reviewerid']."\" name=\"reviewerid\"><input type=\"hidden\" value=\"".$row['conferenceid']."\" name=\"conferenceid\"><button>Delete</button></td></tr></form>";
          }
      }
      else{
        echo "<tr><td>No Reviewers</td></tr>";
      }
      echo "</table>"
  ?>
</div>

</body>
</html>