<?php
	
	$email=$_GET['email'];
	$psw=$_GET['psw'];

	include("connection.php");
	$co=  new Connection1();

	//Connection1::$conn = new mysqli("localhost", "ikram", "1126","conference");

    // Check connection
    if (Connection1::$conn->connect_error) {
        die("Connection failed: " . Connection1::$conn->connect_error);
    }

    $q= "select * from conferenceuser;";

    $result = mysqli_query(Connection1::$conn,$q);
    $flag=false;
    if ($result->num_rows > 0) {
         //output data of each row
        while($row = $result->fetch_assoc()) {
        	if($email==$row['email'] && $psw==$row['psw']){
        		$name=$row['name'];
        		$userid=$row['userid'];
        		$flag=true;
        		$role= $row['role'];
        		break;
        	}	
        }
    }
    if($flag){
    	session_start();
    	$_SESSION['userid']=$userid;
    	$_SESSION['name']=$name;
    	$_SESSION['email']=$email;
    	$_SESSION['role']=$role;
    	if($role=='U'){
	    	echo '<script type="text/javascript">
	           window.location = "http://localhost/cms/userHome.php";
	      	</script>';
      	}
      	else if($role=='A'){
      		echo '<script type="text/javascript">
	           window.location = "http://localhost/cms/adminPanel.php";
	      	</script>';
      	}
    }
    else{
    	$q= "select * from reviewer;";
    	echo "ya chala";
	    $result = mysqli_query(Connection1::$conn,$q);
	    $flag=false;
	    if ($result->num_rows > 0) {
	         //output data of each row
	        while($row = $result->fetch_assoc()) {
	        	if($email==$row['email'] && $psw==$row['psw']){
	        		$name=$row['name'];
	        		$rid=$row['reviewerid'];
	        		$conferenceid=$row['conferenceid'];
	        		$flag=true;
	        		break;
	        	}	
	        }
	    }

	    if($flag){
	    	session_start();
	    	$_SESSION['reviewerid']=$rid;
	    	$_SESSION['name']=$name;
	    	$_SESSION['email']=$email;
	    	$_SESSION['conferenceid']=$conferenceid;
	    	echo '<script type="text/javascript">
		          window.location = "http://localhost/cms/reviewerPanel.php";
		      </script>';
	    }
	    else{
	    	echo "<script>window.alert(\"wrong email or password\")</script>";
	    	echo '<script type="text/javascript">
	           window.location = "http://localhost/cms/login.php";
	      	</script>';
		}

    }
    

?>