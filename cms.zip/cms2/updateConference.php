<!DOCTYPE html>
<html>
<head>
	<title>Update Conference</title>

	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="cssfile1.css">
<link rel="stylesheet" href="cssfile2.css">
<link rel="stylesheet" href="cssfile3.css">
<link rel="stylesheet" href="cssfile4.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
}

/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}
/* The sidebar menu */
.sidenav {

	margin-top: 50px;
  height: 100%; /* Full-height: remove this if you want "auto" height */
  width: 200px; /* Set the width of the sidebar */
  position: fixed; /* Fixed Sidebar (stay in place on scroll) */
  z-index: 1; /* Stay on top */
  top: 0; /* Stay at the top */
  left: 0;
  background-color: #111; /* Black */
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 20px;
}

/* The navigation menu links */
.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
}

/* When you mouse over the navigation links, change their color */
.sidenav a:hover {
  color: #f1f1f1;
}

/* Style page content */
.main {
		margin-top: 50px;
  margin-left: 200px; /* Same as the width of the sidebar */
  padding: 0px 10px;
}

/* On smaller screens, where height is less than 450px, change the style of the sidebar (less padding and a smaller font size) */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}



/* Full-width input fields */
  input[type=text], input[type=password] {
  	
  	margin-left: 5%;
  width: 70%;
  padding: 10px;
  /*margin: 5px 0 22px 0;*/
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}
</style>

</head>

<body>
	<div class="w3-top">
  <div class="w3-bar w3-red w3-card w3-left-align w3-medium">
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-red" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <font style="float:left; font-size: 25px;">Conference Management System</font>
    <a href="logout.php"><button style=" width:8%;float: right; ">log out</button></a>
  </div>
</div>

<!-- Side navigation -->
<div class="sidenav">
  <a style="color: #f1f1f1;" href="adminpanel.php">Conferences</a>
  <a href="adminpanelreviewer.php">Reviewers</a>
  <a href="addConference.php">Add Conference</a>
  <a href="addReviewer.php">Add Reviewer</a>
</div>

<div class="main">
	<table style=" width:80%; border: 1px solid grey;  margin:10%;  float: left; margin-top: 5%;">
		<tr style="padding:0px; background-color: #4c73af;"><td style="color: white; "><h4>&nbsp;&nbsp;&nbsp;&nbsp;Update Conference</h4></td></tr>
	<tr >
	<td>
		
		<?php

			$conn = new mysqli("localhost:3308", "root", "","conference1");
			$conId=$_GET['conferenceid'];
		    // Check connection
		    if ($conn->connect_error) {
		        die("Connection failed: " . $conn->connect_error);
		    }
		    $q= "select * from conference where conferenceid='".$conId."';";

		    $result = mysqli_query($conn,$q);

		    if ($result->num_rows > 0) {
		         //output data of each row
		        while($row = $result->fetch_assoc()) {
		     		echo "<div style=\"padding:30px; \"><form action=\"updateConferencephpCode.php\">
						<input type=\"hidden\" value=".$conId." name=\"conferenceid\"><label for=\"name\"><b>Conference Id</b></label>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$conId."<br>
						<label for=\"name\"><b>Conference Name</b></label>
					    <input value=\"".$row['name']."\" type=\"text\" placeholder=\"Enter Conference Name\" name=\"name\" required><br>
						<table>
							<tr>
								<td style=\"padding:20px; padding-left: 0;\"><label for=\"name\"><b>Description</b></label></td>
								<td style=\"padding:20px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input value=\"".$row['description']."\" style=\"width: 400px; height: 70px;\" name=\"description\"><br></td>
							</tr>
						</table>
						<label for=\"name\"><b>Date</b></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					    <input value=\"".$row['hdate']."\" type=\"date\" placeholder=\"Enter Full Name\" name=\"date\" required><br>

					    <label for=\"name\"><b>Address</b></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					    <input value=\"".$row['address']."\" type=\"text\" placeholder=\"Enter Address\" name=\"address\" required><br>

					    <label for=\"name\"><b>Email</b></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					    <input value=\"".$row['email']."\" type=\"text\" placeholder=\"Enter Email\" name=\"email\" required><button>Update</button></form>
					</div>";
		        }
		    }
		?>

	</td>	
	</tr>
	</table>
</div>

</body>
</html>