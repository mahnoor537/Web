<?php
	class Conference{
		var $name;
		var $description;
		var $hdate;
		var $address;
		var $email;

		function getData(){
			$this->name=$_GET['name'];
			$this->description=$_GET['description'];
			$this->hdate=$_GET['date'];
			$this->address=$_GET['address'];
			$this->email=$_GET['email'];
		}

	}

	include("connection.php");
	$co=  new Connection1();


	$obj = new Conference();
	$obj->getData();

//	$conn = new mysqli("localhost", "ikram", "1126","conference");

	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}

	$q= "insert into conference (name,description,hdate,address,email) values(\"".$obj->name."\",\"".$obj->description."\",'".$obj->hdate."',\"".$obj->address."\",\"".$obj->email."\");";
	echo $q,"\n";
	if(mysqli_query(Connection1::$conn,$q)==true){
		echo "user added<br>  ";
	}
	else {
		echo mysqli_error(Connection1::$conn);
	}
	echo '<script type="text/javascript">
           window.location = "http://localhost/cms/adminpanel.php";
      	</script>';


?>