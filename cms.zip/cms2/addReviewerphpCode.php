<?php
	
	class Reviewer{
		var $conferenceId;
		var $name;
		var $phoneNo;
		var $address;
		var $email;
		var $psw;

		function getData(){
			$this->conferenceId=$_GET['conferenceid'];
			$this->name=$_GET['name'];
			$this->phoneNo=$_GET['phoneNo'];
			$this->address=$_GET['address'];
			$this->email=$_GET['email'];
			$this->psw=$_GET['psw'];
		}

	}

	include("connection.php");
	$co=  new Connection1();

	$obj = new Reviewer();
	$obj->getData();

	//	Connection1::$conn = new mysqli("localhost", "ikram", "1126","conference");

	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}

	$q= "insert into reviewer (conferenceid, name,phoneNo,address ,email,psw) 
		values(".$obj->conferenceId.",\"".$obj->name."\",\"".$obj->phoneNo."\",\"".$obj->address."\",\"".$obj->email."\",\"".$obj->psw."\");";
	if(mysqli_query(Connection1::$conn,$q)==true){
		//echo "user added<br>  ";
	}
	else {
		echo mysqli_error(Connection1::$conn);
	}
	echo '<script type="text/javascript">
           window.location = "http://localhost/cms/adminpanelreviewer.php";
      	</script>';

?>