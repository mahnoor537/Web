<?php
	
	class User{
		var $name;
		var $phoneNo;
		var $email;
		var $psw;
		var $institutionName;

		// User(){
		// 	$phoneNO=$email=$psw=$institutionName=$name="";
		// }

		function getData(){
			$this->name=$_GET["name"];
			$this->phoneNo=$_GET["phoneNo"];
			$this->email=$_GET["email"];
			$this->psw=$_GET["psw"];
			$this->institutionName=$_GET["institutionName"];
		}
		function printData(){
			echo $this->name;
			echo $this->phoneNo;
			echo $this->email;
			echo $this->psw;
			echo $this->institutionName;
		}
	}

	$obj= new User();
	$obj->getData();

	include("connection.php");
	$co=  new Connection1();

	//$conn = new mysqli("localhost", "ikram", "1126","conference");

	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}

	$q= "insert into conferenceuser (name, phoneNo, email, psw, institutionName,role)
		values('$obj->name','$obj->phoneNo','$obj->email','$obj->psw','$obj->institutionName','U');";

	if(mysqli_query(Connection1::$conn,$q)==true){
//		echo "user added<br>  ";
	}
	else {
//		echo "not added\n  ";
	}

	$q= "select * from conferenceuser where email=\"".$obj->email."\"";

	if(mysqli_query(Connection1::$conn,$q)==true){
	//	echo "user added<br>  ";
	}
	else {
	//	echo "not added\n  ";
	}
	session_start();
	
	$result = mysqli_query(Connection1::$conn,$q);
    if ($result->num_rows > 0) {
         //output data of each row
        while($row = $result->fetch_assoc()) {
        	$_SESSION['userid']=$row['userid'];

		}
	}
	$_SESSION['name'] = $obj->name;
	$_SESSION['email'] = $obj->email;
	$_SESSION['status'] = true;

	if($_SESSION['status']){
		echo '<script type="text/javascript">
           window.location = "http://localhost/cms/userHome.php";
      	</script>';
	}

?>