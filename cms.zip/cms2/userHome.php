<!DOCTYPE html>
<html lang="en">
<title>home- CMS</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="cssfile1.css">
<link rel="stylesheet" href="cssfile2.css">
<link rel="stylesheet" href="cssfile3.css">
<link rel="stylesheet" href="cssfile4.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}

button {
  background-color: #4CAF50;
  color: white;
  padding: 12px 5px;
  margin: ;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
</style>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-red w3-card w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-red" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a style="background-color: grey;" href="userHome.php" class="w3-bar-item w3-button w3-padding-large">Upcoming Coferences</a>
    <a href="submittedPapers.php" class="w3-bar-item w3-button w3-padding-large">Submitted Papers</a>
    <a href="logout.php"><button style=" width:8%;float: right; ">log out</button></a>
    <a style=" float:right; background-color: black; padding: 12px; ">
        user: 
      <?php
        session_start();
        echo $_SESSION['name'];
      ?>
    </a>
  </div>
</div>

<!-- Header -->
<header class="w3-container w3-red w3-center" style="padding:20px 16px; padding-top: 50PX;">
  <h1 class="w3-margin w3-jumbo">Conference Management System</h1>
   
</header>

<div style=" padding: 5%;">

  <?php
    $conn = new mysqli("localhost:3308", "root", "","conference1");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $q= "select * from conference;";

    $result = mysqli_query($conn,$q);

    if ($result->num_rows > 0) {
         //output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<div style=\"padding: 20px; margin: 20px; border: 1px solid black; border-radius: 20px;\"><table><tr><form action=\"submitPaper.php\"> <input type=\"hidden\" value=\"".$row['conferenceid']."\" name=\"conferenceid\"> <h3>",$row['name'],"</h3> <b>Happening Date:</b>  ",$row['hdate'],"<br><b>Description: </b>",$row['description'],"</tr><tr><input value=\"Submit Paper\" type=\"submit\"></form></tr></table></div>";
        }
    } else {
        echo "<tr><td>0 results</td></tr>";
    }

  ?>

</div>

</body>
</html>