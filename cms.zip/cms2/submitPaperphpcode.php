<?php

	class Paper{
		var $userid;
		var $conferenceid;
		var $title;
		var $file;

		function getData(){
			session_start();
			$this->conferenceid=$_SESSION['conferenceid'];
			$this->title=$_POST['title'];
			$this->file=$_POST['file'];

			$conn = new mysqli("localhost:3308", "root", "","conference1");

		    // Check connection
		    if ($conn->connect_error) {
		        die("Connection failed: " . $conn->connect_error);
		    }
		    $q= "select * from conferenceuser where name='".$_SESSION['name']."';";

		    $result = mysqli_query($conn,$q);

		    if ($result->num_rows > 0) {
		         //output data of each row
		        while($row = $result->fetch_assoc()) {
		        	$this->userid=$row['userid'];
		        	$_SESSION['userid']=$row['userid'];
		        }
		    }
		}
	}


	$obj = new Paper();
	$obj->getData();	
	$conn = new mysqli("localhost:3308", "root", "","conference1");

	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
	$obj->file = $_FILES["file"]["name"];


	$q= "insert into submittedpaper (userid,conferenceid,title,path,status)
		values(".$obj->userid.",".$obj->conferenceid.",'".$obj->title."','".$obj->file."',-1);";

	$targetDir = "papers/";
$fileName = $_FILES["file"]["name"];

$targetFilePath = $targetDir . $fileName;

$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
$id = $_REQUEST['search1'];
//echo $id;
//global $db;
//$email = $_REQUEST['email1'];
//echo $email;
//echo $fileName;
if(!empty($_FILES["file"]["name"])){
    // Allow certain file formats
    $allowTypes = array('jpg','png','jpeg','gif','pdf','docx');
    if(in_array($fileType, $allowTypes))
    {
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath))
        {
            // Insert image file name into database
            //var_dump('NOW()');
        		$insert=mysqli_query($conn,$q);
	
        		
            //	var_dump($insert);
            if($insert)
            {
                header('Location: http://localhost/cms/userHome.php');
            }
            else
            {
                $statusMsg = "File upload failed, please try again.";
            } 
        }
        else
        {
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }
    else
    {
        $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
    }
}
else
{
    $statusMsg = 'Please select a file to upload.';
}

// Display status message
echo $statusMsg;

?>