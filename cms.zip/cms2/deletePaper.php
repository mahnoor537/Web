<?php
	include("connection.php");
	$co=  new Connection1();

//	Connection1::$conn = new mysqli("localhost", "ikram", "1126","conference");

	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}

	$q= "delete from submittedpaper where paperId=".$_GET['paperId'].";";

	if(mysqli_query(Connection1::$conn,$q)==true){
		//echo "user added<br>  ";
		echo '<script type="text/javascript">
           window.location = "http://localhost/cms/submittedPapers.php";
      	</script>';
	}
	else {
		//echo "not added\n  ";
		echo mysqli_error(Connection1::$conn);
	}
?>