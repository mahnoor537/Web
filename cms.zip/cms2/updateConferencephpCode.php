<?php
	
	class Conference{
		var $conferenceId;
		var $name;
		var $description;
		var $hdate;
		var $address;
		var $email;

		function getData(){
			$this->conferenceId=$_GET['conferenceid'];
			$this->name=$_GET['name'];
			$this->description=$_GET['description'];
			$this->hdate=$_GET['date'];
			$this->address=$_GET['address'];
			$this->email=$_GET['email'];
		}

	}

	$obj = new Conference();
	$obj->getData();

	include("connection.php");
	$co=  new Connection1();

	//$conn = new mysqli("localhost", "ikram", "1126","conference");

	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}

	$q= "update conference set name=\"".$obj->name."\", description=\"".$obj->description."\", hdate=\"".$obj->hdate."\", address=\"".$obj->address."\", email=\"".$obj->email."\" where conferenceid=".$obj->conferenceId.";";
	if(mysqli_query(Connection1::$conn,$q)==true){
		echo "user added<br>  ";
	}
	else {
		echo mysqli_error(Connection1::$conn);
	}
	echo '<script type="text/javascript">
           window.location = "http://localhost/cms/adminpanel.php";
      	</script>';

?>