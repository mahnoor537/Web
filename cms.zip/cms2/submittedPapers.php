<!DOCTYPE html>
<html lang="en">
<title>home- CMS</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}

button {
  background-color: #4CAF50;
  color: white;
  padding: 12px 5px;
  margin: ;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

table{
    text-align: center;
  }
  table {
    float: left;
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 90%;
  margin: 5%;
}

table td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4c73af;
  color: white;
}

  th{
    color :white;
    background-color: #4c73af;
  }
</styl
</style>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-red w3-card w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-red" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a " href="userHome.php" class="w3-bar-item w3-button w3-padding-large">Upcoming Coferences</a>
    <a style="background-color: grey;" href="submittedPapers.php" class="w3-bar-item w3-button w3-padding-large">Submitted Papers</a>
    <a href="logout.php"><button style=" width:8%;float: right; ">log out</button></a>
    <a style=" float:right; background-color: black; padding: 12px; ">
        user: 
      <?php
        session_start();
        echo $_SESSION['name'];
      ?>
    </a>
  </div>
</div>

<!-- Header -->
<header class="w3-container w3-red w3-center" style="padding:20px 16px; padding-top: 50PX;">
  <h1 class="w3-margin w3-jumbo">Conference Management System</h1>
   
</header>

<div style=" padding: 5%;">

  <?php
    $conn = new mysqli("localhost:3308", "root", "","conference1");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $q= "select * from submittedpaper where userId=".$_SESSION['userid'].";";

    $result = mysqli_query($conn,$q);
    echo "<table style=\"margin-top:0px;\"> <th>P No.</th><th>Title</th><th>Conference Id.</th><th>Status</th><th></th>";
    if ($result->num_rows > 0) {
         //output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row['paperId']."</td><td>".$row['title']."</td><td>".$row['conferenceid']."</td>";
            if($row['status']==1){
              echo "<td style = \"color: green;\"><b>Accepted</b></td></tr>";
            }
            else if($row['status']==-1){
              echo "<td>Pending</td></tr>";
            }
            else if($row['status']==0){
              echo "<td>Accepted for final submission</td><td><form action=\"submitFinalPaper.php\"><input type=\"hidden\" value=".$row['paperId']." name=\"paperId\"><button>submit final</button></td></form>"; 
            }
            else if($row['status']=-2){
              echo "<td style=\"color:red;\"><b>Rejected</b></td><td><form action=\"deletePaper.php\"><input type=\"hidden\" value=".$row['paperId']." name=\"paperId\"><button style=\"background-color:red;\">Delete</button></form></td>"; 
            }
        }
    } else {
        echo "<tr><td>0 results</td></tr>";
    }

  ?>

</div>

</body>
</html>