<?php
	include("connection.php");
	$co=  new Connection1();

//	Connection1::$conn = new mysqli("localhost", "ikram", "1126","conference");


	$rId= $_GET['reviewerid'];	
	// Check connection
	if (Connection1::$conn->connect_error) {
	    die("Connection failed: " . Connection1::$conn->connect_error);
	}

	$q= "delete from reviewer where reviewerid=".$rId.";";
	
	if(mysqli_query(Connection1::$conn,$q)==true){
		//echo "user added<br>  ";
	}
	else {
		echo "<script>window.alert(\"Conference can not be deleted. It could have accepted some papers\")</script>";
	}
	echo '<script type="text/javascript">
           window.location = "http://localhost/cms/adminpanelreviewer.php";
      	</script>';
?>